package game;

public class TicTaCToeTakenException extends Exception {


	private static final long serialVersionUID = 1L;

	public TicTaCToeTakenException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
