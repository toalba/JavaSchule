package game;

public enum XorO {
	X, O
}
