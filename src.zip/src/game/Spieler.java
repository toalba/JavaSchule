package game;

public enum Spieler {
	CROSS, CIRCLE
}
